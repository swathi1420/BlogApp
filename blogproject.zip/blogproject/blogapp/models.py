from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
# Create your models here.

class Article(models.Model):
    title = models.CharField(max_length=150)
    content = models.TextField()
    created_date = models.DateField(default=datetime.now)
    is_publish = models.BooleanField(default=False)
    published_date = models.DateField()
    author = models.ForeignKey(User,on_delete=models.CASCADE)

    

