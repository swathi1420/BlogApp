from django.urls import path
from .views import DisplayBlogs,DetailBlog,UpdateBlog,DeleteBlog,AddBlog
from . import views
from django.contrib.auth import views as auth_views

app_name = 'blogapp'
urlpatterns = [
   path('', DisplayBlogs.as_view(), name= 'displayblog'),
   path('<int:pk>/', DetailBlog.as_view()),
   path('<int:pk>/update/', UpdateBlog.as_view(template_name="update_blog.html"),name='update'), 
   path('login/',auth_views.LoginView.as_view(template_name="login.html"), name='login'),
   path('logout/',auth_views.LogoutView.as_view(),name ='logout'),
   path('addblog/',AddBlog.as_view(template_name="addblog.html"), name='addblog'),
   path('<int:pk>/delete', DeleteBlog.as_view(), name='deleteblog'),
   
   
] 
