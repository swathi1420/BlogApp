from django.shortcuts import render,redirect
from django.views import View
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView,DeleteView,CreateView
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.contrib.auth import logout
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from blogapp.models import Article
from django.urls import reverse_lazy
import logging
# Create your views here.

logger = logging.getLogger(__name__)

# To list the blogs
class DisplayBlogs(ListView):
    model = Article
    template_name = 'display_blog.html'
    context_object_name = 'blog'

    def get_queryset(self):
        queryset = Article.objects.all()
        if self.request.user.is_authenticated:
            queryset = queryset.filter(author_id = self.request.user)
            return queryset
        return queryset


# To view a particular blog in detail
class DetailBlog(DetailView):
    model = Article
    template_name = 'detail_blog.html'


# To edit the blogs
class UpdateBlog(UpdateView):
    model = Article
    fields = [
        "title", 
        "content", 
        "created_date"
    ]
    success_url = '/'


# To delete the blog
class DeleteBlog(DeleteView):
    model = Article  # model
    success_url = '/'  # redirect url


# Create new blog
class AddBlog(CreateView):
    model = Article
    fields = [
        "title",
        "content",
        "created_date",
        "published_date"
    ]
    success_url = reverse_lazy('blogapp:displayblog')

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    
# Delete the blogs
class DeleteBlog(DeleteView):
    model = Article
    success_url = "/"





